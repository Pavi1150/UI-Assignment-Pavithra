export const data = {
  labels: ["5", "9", "11", "13", "15", "17", "19", "21", "23", "25"],
  datasets: [
    {
      label: "",
      data: [0, 20,10,15,25],
      backgroundColor: "rgba(127, 156, 228, 0.5)",
    //   borderColor: "rgba(127, 156, 228, 1)", 
      borderWidth: 1 ,
      borderRadius:100,
      borderSkipped: false,
    }
  ]
};
