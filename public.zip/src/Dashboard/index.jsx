import React from 'react'
import "./style.css"
import dashboardIcon from "../Icons/dashboards.png"
import home from "../Icons/home.png"
import graph from "../Icons/square.png"
import shopping from "../Icons/shopping.png"
import search from "../Icons/search.png"
import setting from "../Icons/setting.png"
import bell from "../Icons/bell.png"
import email from "../Icons/email.png"
import order from "../Icons/orders.png"
import right from "../Icons/right.png"
import star from "../Icons/star.png"
import user from "../Icons/user.png"
import VerticalBarChart from '../Charts/VerticalBarChart'
import ChartComponent from '../Charts/VerticalBarChart'
import BarChart from '../Charts/VerticalBarChart'
import { data } from '../Charts/data'
import { FaShoppingBasket } from "react-icons/fa";
import { GiShoppingBag } from "react-icons/gi";
import { FaCommentsDollar } from "react-icons/fa6";
import { RxTriangleUp } from "react-icons/rx";
import { RxTriangleDown } from "react-icons/rx";
import { TbLayoutDashboardFilled } from "react-icons/tb";
import { MdOutlineInsertChart } from "react-icons/md";
import { LuClipboardCheck } from "react-icons/lu";
import { TbDeviceIpadHorizontalSearch } from "react-icons/tb";
import { HiOutlineDocumentCheck } from "react-icons/hi2";
import { GoHomeFill } from "react-icons/go";
import { IoSettingsOutline } from "react-icons/io5";
import { FaRegBell } from "react-icons/fa";
import { HiOutlineMail } from "react-icons/hi";
import { LuGoal } from "react-icons/lu";
import { BiDish } from "react-icons/bi";
import { TbBurger } from "react-icons/tb";
import CircularProgress from '../Charts/CircularProgress'
import { CgProfile } from "react-icons/cg";
import { FiSearch } from "react-icons/fi";
const Dashboard = () => {
  const tableData = [
    {
      customer: "Wade",
      orderNo: 1234567,
      amount: "$124.00",
      status: "Delivered"
    },
    {
      customer: "Jane",
      orderNo: 12578934,
      amount: "$365.02",
      status: "Delivered"
    }, {
      customer: "Christin",
      orderNo: 124678,
      amount: "$45.88",
      status: "Cancelled"
    }, {
      customer: "cody",
      orderNo: 187542,
      amount: "$65.00",
      status: "Cancelled"
    }, {
      customer: "Hawkins",
      orderNo: 135346,
      amount: "$545.00",
      status: "Delivered"
    }, {
      customer: "Savannah",
      orderNo: 196598,
      amount: "$128.20",
      status: "Delivered"
    },
  ]

  return (
    <div>
      <div className='d-flex'>
        <div className='icons-section'>
          <div>
            <div className='mt-2 d-flex justify-content-center'>
              {/* <img src={dashboardIcon} height="30px" width="30px" color='white' /> */}
              <TbLayoutDashboardFilled size="50" className='icons-container'/>
            </div>
            <div className='mt-4 d-flex justify-content-center'>
              <GoHomeFill size="30" className='icons-container'/>
              {/* <img src={home} height="30px" width="30px" /> */}
            </div>
            <div className='mt-4 d-flex justify-content-center'>
              <MdOutlineInsertChart size="30" className='icons-container'/>
              {/* <img src={graph} height="30px" width="30px" /> */}
            </div>
            <div className='mt-4 d-flex justify-content-center'>
              {/* <img src={shopping} height="40px" width="40px" /> */}

              <LuClipboardCheck size="30" className='icons-container'/>
            </div>
            <div className='mt-4 d-flex justify-content-center'>
              {/* <img src={shopping} height="40px" width="40px" /> */}
              <TbDeviceIpadHorizontalSearch size="30" className='icons-container'/>
            </div>
            <div className='mt-4 d-flex justify-content-center'>
              {/* <img src={shopping} height="40px" width="40px" /> */}
              <HiOutlineDocumentCheck size="30" className='icons-container'/>
            </div>
          </div>
        </div>
        <div className='header-section '>
          <div className='d-flex justify-content-between p-3 header-background position-relative'>
            <div className='input-section'>
              <FiSearch className='search-icon' color='white' size="25"/>
              <input placeholder='search' className='rounded py-2 px-3 search' />
            </div>
            <div>
              <IoSettingsOutline color='white' size="30" className='me-4' />
              <FaRegBell color='white' size="30" className='me-4' />
              <HiOutlineMail color='white' size="30" className='me-4' />
              {/* <img src={setting} height="30px" width="30px" color='white' className='me-4' />
              <img src={bell} height="30px" width="30px" className='me-4' />
              <img src={email} height="30px" width="30px" className='me-4' /> */}
            </div>
          </div>
          <div className='bg-black p-3'>
            <h4 className='fw-bold text-white '>Dashboard</h4>
            <div className='row mt-4'>
              <div className='col-8'>
                <div className='row'>
                  <div className='col-3'>
                    <div className='card-section shadow mb-5 p-2 rounded'>
                      <div >
                      <FaShoppingBasket color="rgb(112, 146, 173)" size="50" className='rounded p-2' style={{backgroundColor:"rgb(203, 224, 241)"}}/>
                      </div>
                      <p className='text-white fw-bold'>Total Orders</p>
                      <div className='mt-5 d-flex justify-content-between'>
                        <h1 className='text-white fw-bold'>75</h1>
                        <h5 style={{ color: "#2ac67d" }} className='fw-bold mt-3'><RxTriangleUp color='#2ac67d' />3%</h5>
                      </div>
                    </div>
                  </div>
                  <div className='col-3'>
                    <div className='card-section shadow mb-5 p-2 rounded'>
                      {/* <img src={order} width="50px" height="50px" /> */}
                      <GiShoppingBag color='#2ac67d' size="50"  className='rounded p-2' style={{backgroundColor:'rgb(146 231 173)'}}/>
                      <p className='text-white fw-bold'>Total Delivered</p>
                      <div className='mt-5 d-flex justify-content-between'>
                        <h1 className='text-white fw-bold'>70</h1>
                        <h5 style={{ color: "#dc4621" }} className='fw-bold mt-3'><RxTriangleDown color='#dc4621' />3%</h5>
                      </div>
                    </div>
                  </div>
                  <div className='col-3'>
                    <div className='card-section shadow mb-5 p-2 rounded'>
                      <GiShoppingBag color='#dc4621' size="50" className='rounded p-2' style={{backgroundColor:'rgb(239 179 164)'}}/>
                      <p className='text-white fw-bold'>Total Cancelled</p>
                      <div className='mt-5 d-flex justify-content-between'>
                        <h1 className='text-white fw-bold'>05</h1>
                        <h5 style={{ color: "#2ac67d" }} className='fw-bold mt-3'><RxTriangleUp color='#2ac67d' />3%</h5>
                      </div>
                    </div>
                  </div>
                  <div className='col-3'>
                    <div className='card-section shadow mb-5 p-2 rounded'>
                      <FaCommentsDollar color='#e752bc' size="50"  className='rounded p-2' style={{backgroundColor:'rgb(251 165 226)'}}/>
                      <p className='text-white fw-bold'>Total Revenue</p>
                      <div className='mt-5 d-flex justify-content-between'>
                        <h1 className='text-white fw-bold'>$12k</h1>
                        <h5 style={{ color: "#dc4621" }} className='fw-bold mt-3'><RxTriangleDown color='#dc4621' />3%</h5>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='col-4'>
                <div className='card-section shadow mb-5 rounded d-flex'>
                  <div className='py-5 px-3'>
                    <h6 className='text-white'>Net Profit</h6>
                    <h1 className='text-white fw-bold'>$6759.25</h1>
                    <div className=''>
                      <h5 style={{ color: "#2ac67d" }} className='fw-bold mt-3'><RxTriangleUp color='#2ac67d' />3%</h5>
                    </div>
                  </div>
                  <div className='mt-4 ms-2 circularProgress'>
                  <CircularProgress/>
                  </div>

                </div>
              </div>
            </div>
            <div className='row mb-2'>
              <div className='col-8'>
                <div className='colorBackground rounded p-3'>
                  <h3 className='fw-bold text-white'>Activity</h3>
                  <BarChart data={data} />
                </div>
              </div>
              <div className='col-4'>
                <div className='colorBackground shadow p-4 mb-5 rounded'>
                  <div className="d-flex justify-content-between align-items-center" >
                    <div className='d-flex py-3'>
                      <div className='rounded-circle goal p-3'>
                        <LuGoal color='#e87509' size="40" /></div>
                      <h5 className='text-white d-flex align-items-center ms-3'>Goals</h5>
                    </div>
                    <div className='bg-secondary rounded-circle p-2' >
                    <img src={right} width="20px" height="20px"/>
                    </div>
                  </div>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className='d-flex py-3'>
                      <div className='rounded-circle dish p-3'>
                        <TbBurger color='rgba(127, 156, 228, 0.5)' size="40" /></div>
                      <h5 className='text-white d-flex align-items-center ms-3'>Popular Dishes</h5>
                    </div>
                    <div className='bg-secondary rounded-circle p-2' >
                    <img src={right} width="20px" height="20px"/>
                    </div>
                  </div>
                  <div className="d-flex justify-content-between align-items-center">
                    <div className='d-flex py-3'>
                      <div className='rounded-circle menu p-3'>
                        <BiDish color='#34d6b4' size="40" /></div>
                      <h5 className='text-white d-flex align-items-center ms-3'>Menu</h5>
                    </div>
                    <div className='bg-secondary rounded-circle p-2' >
                    <img src={right} width="20px" height="20px"/>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='row'>
              <div className='col-8'>

                <div className='colorBackground shadow p-5 mb-5 rounded'>
                  <h4 className='fw-bold text-white'>Recent Orders</h4>
                  <table className='table table-dark colorBackground'>
                    <thead>
                      <th>Customer</th>
                      <th>Order No.</th>
                      <th>Amount</th>
                      <th>Status</th>
                    </thead>
                    {tableData.map((x, index) => (
                      <tbody className='colorBackground p-5'>

                        <tr key={index}>
                          <td><CgProfile size="30px" color='white' className='me-2'/>{x.customer}</td>
                          <td>{x.orderNo}</td>
                          <td>{x.amount}</td>
                          <td><span className={x?.status=="Delivered" ? "delivered":"cancelled"}>{x.status}</span></td>
                        </tr>
                      </tbody>

                    ))}
                  </table>

                </div>
              </div>
              <div className='col-4'>
                <div className='colorBackground shadow p-3 mb-3 rounded'>
                  <h4 className='fw-bold text-white mb-4'>Customerr Feedback</h4>
                  <div>
                    <div className='d-flex mb-2'>
                      <CgProfile size="40px" color='white'/>
                      <h5 className='fw-bold text-white ms-2 mt-1'>Jenny Wilson</h5>
                    </div>
                    <div className='mb-2'>
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                    </div>
                    <div className='text-white'>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                      the industry's standard dummy text ever since the 1500s, when an unknown
                      printer took a galley of type and scrambled it to make a type specimen book.
                    </div>
                    <hr className='text-white' />
                  </div>

                  <div>
                    <div className='d-flex mb-2'>
                      <CgProfile size="40px" color='white'/>
                      <h5 className='fw-bold text-white ms-2 mt-1'>Jenny Wilson</h5>
                    </div>
                    <div className='mb-2'>
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                    </div>
                    <div className='text-white fs-6'>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                      the industry's standard dummy text ever since the 1500s, when an unknown
                      printer took a galley of type and scrambled it to make a type specimen book.
                    </div>
                    <hr className='text-white' />
                  </div>

                  <div>
                    <div className='d-flex mb-2'>
                      <CgProfile size="40px" color='white'/>
                      <h5 className='fw-bold text-white ms-2 mt-1'>Jenny Wilson</h5>
                    </div>
                    <div className='mb-2'>
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                      <img src={star} width="20px" height="20px" />
                    </div>
                    <div className='text-white fs-6'>
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                      the industry's standard dummy text ever since the 1500s, when an unknown
                      printer took a galley of type and scrambled it to make a type specimen book.
                    </div>
                    <hr className='text-white' />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard